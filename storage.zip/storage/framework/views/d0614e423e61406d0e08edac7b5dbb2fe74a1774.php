<div style="text-align:center;">
    <div class="game_qb_title">
        <div class="game_qb_left">
           Popular
        </div>
        <div class="game_qb_left" style="text-align:right;">
            <a href="#navigations" style="text-decoration:none" onclick="myclick(9)">Ver tudo</a>
        </div>
    </div>
    
    <div class="game_list rm">
    <?php $__currentLoopData = $favorRecommend; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a><img _ngcontent-avh-c16="" gameid="<?php echo e($item['id']); ?>" class=" generic-background-image pg_game_go ng-star-inserted" src="<?php echo e($item['icon']); ?>" /></a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>      
    </div>
    
    <div class="game_qb_title">
        <div class="game_qb_left">
          In-PG
        </div>
        <div class="game_qb_left" style="text-align:right;">
            <a href="#navigations" style="text-decoration:none" onclick="myclick(2)">Ver tudo</a>
        </div>
    </div>
    
    <div class="game_list">
    <?php $__currentLoopData = $pgRecommend; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a><img _ngcontent-avh-c16="" gameid="<?php echo e($item['id']); ?>" class=" generic-background-image pg_game_go ng-star-inserted" src="<?php echo e($item['icon']); ?>" /></a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
    </div>
    
    <div class="game_qb_title">
        <div class="game_qb_left">
            In-PP
        </div>
        <div class="game_qb_left" style="text-align:right;">
            <a href="#navigations" style="text-decoration:none" onclick="myclick(1)">Ver tudo</a>
        </div>
    </div>
    
    <div class="game_list">
    <?php $__currentLoopData = $ppRecommend; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a><img _ngcontent-avh-c16="" gameid="<?php echo e($item['id']); ?>" class=" generic-background-image pg_game_go ng-star-inserted" src="<?php echo e($item['icon']); ?>" /></a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
    </div>

    
    <div class="game_qb_title">
        <div class="game_qb_left">
           In-Tada
        </div>
        <div class="game_qb_left" style="text-align:right;">
            <a href="#navigations" style="text-decoration:none" onclick="myclick(3)">Ver tudo</a>
        </div>
    </div>
    
    <div class="game_list">
    <?php $__currentLoopData = $getTadaRecommend; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a><img _ngcontent-avh-c16="" gameid="<?php echo e($item['id']); ?>" class=" generic-background-image pg_game_go ng-star-inserted" src="<?php echo e($item['icon']); ?>" /></a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
    </div>
</div><?php /**PATH /Users/lulisong/盒子/bragame/resources/views/black/index/game_recommend.blade.php ENDPATH**/ ?>