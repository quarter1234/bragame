
    <div class="loadings">
          <div class="gif"><img src="https://www.betbra.net:8032/bx_1/public/static/images/20150210104952902.gif" /></div>
    </div>
  <style>
  .loadings{width:100%;height:100%;position:fixed; background:rgba(0,0,0,.5);z-index:9999;top:0;left:0;display: none;}
  .gif{width:32px;height:32px; position:absolute;top:50%;left:50%;margin:-16px 0 0 -16px;}
</style>
<script>
  function showLoading() {
    $('.loadings').show()
  }

  function hideLoading() {
    $('.loadings').hide()
  }
</script>
<?php /**PATH /Users/lulisong/盒子/bragame/resources/views/brling/common/loading.blade.php ENDPATH**/ ?>