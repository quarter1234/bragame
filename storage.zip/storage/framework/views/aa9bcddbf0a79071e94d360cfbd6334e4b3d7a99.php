<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="email_list">
    <a href="<?php echo e(route('mobile.email.info', ['id' => $item['id']])); ?>">
        <img src="/mobile/black/images/email_ico.png" />
        <div class="email_xx1"></div>
        <div class="email_xx2"></div>
        <div class="email_wk">
            <div class="email_w">Receba sua recompensa</div>
            <div class="email_w_bottom xg_bottom">
                <div class="email_w_left">
                <img src="https://bxgames3.s3.sa-east-1.amazonaws.com/bx_1/public/mobile/img/jb.png" />
                <?php echo e($item['attach'][1] ?? 0); ?> 
                </div>
                <div class="email_w_right"><?php echo e($item['timestamp']); ?></div>
            </div>
        </div>
        <?php if($item['hasread'] == 0): ?>
        <div class="email_hd"></div>
        <?php endif; ?>
    </a>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
<?php /**PATH /Users/lulisong/盒子/bragame/resources/views/pink/email/email_list.blade.php ENDPATH**/ ?>