<title></title>
<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1, user-scalable=no, viewport-fit=cover">
<script src="https://baxigame1.s3.sa-east-1.amazonaws.com/bx_4/public/static/js/jquery-3.1.1.min.js"></script><?php /**PATH G:\www\gitapp\bragame\resources\views/black/common/common_title.blade.php ENDPATH**/ ?>