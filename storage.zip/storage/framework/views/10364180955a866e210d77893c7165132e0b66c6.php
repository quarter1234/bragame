<div style="width:100%;text-align:center;">
    <div class="game_qb_title">
        <div class="game_qb_left">
            <span class="game_ico"></span>Popular
        </div>
        <div class="game_qb_left" style="text-align:right;">
            <a href="#navigation" onclick="myclick(9)" style="padding-right:20px;text-decoration:none;">Ver tudo</a>
        </div>
    </div>
    
    <div class="game_list rm">
    <?php $__currentLoopData = $favorRecommend; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a><img _ngcontent-avh-c16="" gameid="<?php echo e($item['id']); ?>" class=" generic-background-image pg_game_go ng-star-inserted" src="<?php echo e($item['icon']); ?>" /></a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>      
    </div>
    
    <div class="game_qb_title">
        <div class="game_qb_left">
            <span class="pp_game"></span>In-PG
        </div>
        <div class="game_qb_left" style="text-align:right;">
            <a href="#navigation" onclick="myclick(2)" style="padding-right:20px;text-decoration:none;">Ver tudo</a>
        </div>
    </div>
    
    <div class="game_list">
    <?php $__currentLoopData = $pgRecommend; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a><img _ngcontent-avh-c16="" gameid="<?php echo e($item['id']); ?>" class=" generic-background-image pg_game_go ng-star-inserted" src="<?php echo e($item['icon']); ?>" /></a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
    </div>
    
    <div class="game_qb_title">
        <div class="game_qb_left">
            <span class="pg_game"></span>In-PP
        </div>
        <div class="game_qb_left" style="text-align:right;">
            <a href="#navigation" onclick="myclick(1)" style="padding-right:20px;text-decoration:none;">Ver tudo</a>
        </div>
    </div>
    
    <div class="game_list">
    <?php $__currentLoopData = $ppRecommend; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a><img _ngcontent-avh-c16="" gameid="<?php echo e($item['id']); ?>" class=" generic-background-image pg_game_go ng-star-inserted" src="<?php echo e($item['icon']); ?>" /></a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
    </div>
</div><?php /**PATH /Users/lulisong/盒子/bragame/resources/views/mobile/index/game_recommend.blade.php ENDPATH**/ ?>