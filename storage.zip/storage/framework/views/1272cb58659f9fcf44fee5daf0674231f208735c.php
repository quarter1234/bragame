<div class="top">
    <div class="black"><img src="https://www.betbra.net:8032/bx_1/public/mobile/img/left_ico.png" /></div>
   
    <div class="money" style="float:right;margin-right:10px">
        <span>R$</span>
        <span><?php echo e($user['coin']); ?></span>
        <div class="sx"><img src="https://www.betbra.net:8032/bx_1/public/mobile/img/sx.png" /></div>
        <div class="qb"><img onclick="location.href='<?php echo e(url("mobile/pay/recharge")); ?>'" src="/mobile/black/images/qb.png" /></div>
    </div>

    
</div>
<script>
$(function(){
    $('.sx').click(function(){
        location.reload(true)
    })
    $('.black').click(function(){
        // window.history.go(-1);
        window.location.href= "<?php echo e(url('mobile/index')); ?>"
    })
})
</script>
<style>
    .black{
        float:left;
        margin:20px 0px 0 5px;
    }
    .black img{
        width:20px;
        height:20px;
    }
    .logo{
        margin-left:0;
    }
    .top{
        z-index:9999;
        top:0;
    }
</style><?php /**PATH /Users/lulisong/盒子/bragame/resources/views/pink/common/top_sub.blade.php ENDPATH**/ ?>