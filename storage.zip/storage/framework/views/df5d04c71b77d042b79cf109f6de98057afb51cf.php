

<div _ngcontent-way-c10="" class="tab-bar safe-area-fix-bottom safe-area-fix-left safe-area-fix-right" jxsafeareafixbottom="" jxsafeareafixleft="" jxsafeareafixright="">
    <button _ngcontent-way-c10="" class="tab-bar__nav-btn safe-area-fix-bottom safe-area-fix-left <?php if(getCurrentControllerName() == 'App\Http\Controllers\Mobile\IndexController'): ?>  tab-bar__nav-btn--active <?php endif; ?>" onclick="location.href='<?php echo e(url("mobile/index")); ?>'" jxsafeareafixleft="" routerlink="/home" routerlinkactive="tab-bar__nav-btn--active" tabindex="0">
        <span _ngcontent-way-c10="" class="tab-bar__nav-btn__icon tab-bar__nav-btn__icon--home"></span>
        <span _ngcontent-way-c10="" class="tab-bar__nav-btn__title">Casa</span>
    </button>

    <button _ngcontent-way-c10="" class="tab-bar__nav-btn safe-area-fix-bottom <?php if(getCurrentControllerName() == 'App\Http\Controllers\Mobile\ActivityController'): ?>  tab-bar__nav-btn--active <?php endif; ?>" onclick="location.href='<?php echo e(url("mobile/activity")); ?>'" routerlinkactive="tab-bar__nav-btn--active" tabindex="0">
        <span _ngcontent-way-c10="" class="tab-bar__nav-btn__icon tab-bar__nav-btn__icon--activity"></span>
        <span _ngcontent-way-c10="" class="tab-bar__nav-btn__title">Atividades</span>
    </button>

    <button _ngcontent-way-c10="" class="tab-bar__nav-btn safe-area-fix-bottom <?php if(getCurrentControllerName() == 'App\Http\Controllers\Mobile\ShareController'): ?>  tab-bar__nav-btn--active <?php endif; ?>" onclick="location.href='<?php echo e(url("mobile/share")); ?>'">
        <span _ngcontent-way-c10="" class="tab-bar__nav-btn__icon tab-bar__nav-btn__icon--cs"></span>
        <span _ngcontent-way-c10="" class="tab-bar__nav-btn__title">Convidar</span>
    </button>

    <button _ngcontent-way-c10="" class="tab-bar__nav-btn safe-area-fix-bottom <?php if(getCurrentControllerName() == 'App\Http\Controllers\Mobile\ShopController'): ?>  tab-bar__nav-btn--active <?php endif; ?>" onclick="location.href='<?php echo e(url("mobile/shop")); ?>'">
        <span _ngcontent-way-c10="" class="tab-bar__nav-btn__icon tab-bar__nav-btn__icon--brand"></span>
        <span _ngcontent-way-c10="" class="tab-bar__nav-btn__title">preferenciais</span>
    </button>

    <button _ngcontent-way-c10="" class="tab-bar__nav-btn safe-area-fix-bottom safe-area-fix-right <?php if(getCurrentControllerName() == 'App\Http\Controllers\Mobile\MemberController'): ?>  tab-bar__nav-btn--active <?php endif; ?>" onclick="location.href='<?php echo e(url("mobile/member/index")); ?>'" routerlinkactive="tab-bar__nav-btn--active" tabindex="0">
        <span _ngcontent-way-c10="" class="tab-bar__nav-btn__icon tab-bar__nav-btn__icon--my"></span>
        <span _ngcontent-way-c10="" class="tab-bar__nav-btn__title">Meu</span>
    </button>
</div><?php /**PATH /Users/lulisong/盒子/bragame/resources/views/brling/common/footer.blade.php ENDPATH**/ ?>