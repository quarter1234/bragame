<title></title>
<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1, user-scalable=no, viewport-fit=cover">
<link rel="shortcut icon" href="/mobile/brling/img/brling.ico" />
<script src="https://www.betbra.net:8032/bx_1/public/static/js/jquery-3.1.1.min.js"></script><?php /**PATH /Users/lulisong/盒子/bragame/resources/views/brling/common/common_title.blade.php ENDPATH**/ ?>