<div class="yh_top">
        <div class="yh_t_list">
            <h2><?php echo e($invite['one_grade_count']); ?></h2>
            <p>Convite nível 1</p>
        </div>
        <div class="yh_t_list">
            <h2><?php echo e($invite['two_grade_count']); ?></h2>
            <p>Convite nível 2</p>
        </div>
</div>


<?php echo $__env->make('mobile.common.loading', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="yh_table">
    <table>
        <thead>
        <tr>
      
            <td>prenome</td>
            <td>série</td>
            <td>tempo</td>
        </tr>
        </thead>
        <tbody id="tab3_content_invites">
        </tbody>
    </table>
    
    <div style="width:100%;text-align:center;margin-top:1rem">
        <button id="invite_load_more" page="0" onclick="loadInvites()"  style="color:#fff; font-size:14px;padding: 5px 10px;background:rgba(0, 0, 0, .2);border-radius: 5px;font-size: 14px;">Carregue mais</button>
    </div>

</div>

<script>
    function loadInvites() {
        let page = $('#invite_load_more').attr('page');
          showLoading();
          $.ajax({
              url : "<?php echo e(url('mobile/share/invites')); ?>",
              type : 'GET',
              data : {page: parseInt(page) + 1},
              success : function (data) {
                hideLoading();
                $('#invite_load_more').attr('page', data.data.current_page);
                data.data.data.forEach(element => {
                    let item = '<tr><td>'+element.descendant.playername+'</td><td>'+element.ancestor_h+'</td><td>'+element.descendant.create_time+'</td></tr>';
                  $('#tab3_content_invites').append(item)
                })
              }
          })
    }
    
    $(document).ready(function() {
        loadInvites();  
    })
</script><?php /**PATH /Users/lulisong/盒子/bragame/resources/views/green/share/user.blade.php ENDPATH**/ ?>