<div class="top">
    
    <div class="money" style="float:right;margin-right:10px">
        <span>R$</span>
        <span><?php echo e($user['coin']); ?></span>
        <div class="sx"><img src="https://www.betbra.net:8032/bx_1/public/mobile/img/sx.png" /></div>
        <div class="qb"><img onclick="location.href='<?php echo e(url("mobile/pay/recharge")); ?>'" src="/mobile/black/images/qb.png" /></div>
    </div>

    
</div>
<script>
$(function(){
    $('.sx').click(function(){
        location.reload(true)
    })
})
</script>
<style>
    .top{
        z-index:9999;
        top:0;
    }
</style><?php /**PATH /Users/lulisong/盒子/bragame/resources/views/black/common/top.blade.php ENDPATH**/ ?>