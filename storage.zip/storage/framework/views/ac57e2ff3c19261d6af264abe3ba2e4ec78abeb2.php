<?php if(Auth::check() && $indexNotice && $indexNotice['status'] == 1): ?>
<div class="gg_db">
                    <div class="gg_tc">
                        <div class="gg_tc_title">
                            <span>noticias oficiais</span>
                            <label><a></a></label>
                        </div>
                        <div class="gg_tc_tit">
                            <h2>Primeiro deposito</h2>
                            <p><?php echo e(date('Y-m-d', $indexNotice['create_time'])); ?></p>
                        </div>
                        <div class="gg_centen"><img src="<?php echo e($indexNotice['img']); ?>" />
                     
                        <?php echo $indexNotice['content']; ?>

                    </div>

                    </div>
            </div>
<?php endif; ?>
<script>
    function showNotice() {
        $('.gg_db').show()
    }
    $(function(){
        showNotice();
        $('.gg_tc a').click(function(){
            $('.gg_db').hide()
        })
    })
</script>            
<?php /**PATH /Users/lulisong/盒子/bragame/resources/views/green/index/notice.blade.php ENDPATH**/ ?>