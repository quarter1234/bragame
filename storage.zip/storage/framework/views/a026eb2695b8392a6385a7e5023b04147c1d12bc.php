<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="rechare_list">
        
        <div class="email_wk" style="width:330px;">
            <div class="rechare_zt">Montante da aposta: <?php echo e($item['coins']); ?></div>
        </div>
        <div class="email_w_bottom xg">
                <div class="email_w_left">
                <img src="https://www.betbra.net:8032/bx_1/public/mobile/img/jb.png" />
               <?php echo e($item['coin'] ?? 0); ?>  
                
                
              
                </div>
                <div class="email_w_right"><?php echo e($item['time']); ?></div>
            </div>
       
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  <?php /**PATH /Users/lulisong/盒子/bragame/resources/views/black/member/bet_list.blade.php ENDPATH**/ ?>