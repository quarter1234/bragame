<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="rechare_list">
    
        <img src="../../mobile/black/images/dd_ico.png" />
        <div class="email_xx1"></div>
        <div class="email_xx2"></div>
        <div class="email_wk">
            <div class="email_w "><?php echo e($item['orderid']); ?></div>
            <div class="rechare_zt xg_zt"><?php echo e($item['format_status']); ?></div>
            <div class="email_w_bottom xg_bottom">
                <div class="email_w_left">
                <img src="../../mobile/img/jb.png" />
                <?php echo e($item['count'] ?? 0); ?>  
                </div>
                <div class="email_w_right"><?php echo e($item['format_create_time']); ?></div>
            </div>
        </div>
       <div class="rechare_button copy_btn"  data-clipboard-text="<?php echo e($item['orderid']); ?>">Cópia</div> 
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  <?php /**PATH /Users/lulisong/盒子/bragame/resources/views/pink/member/rechare_list.blade.php ENDPATH**/ ?>