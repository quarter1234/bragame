<div class="times">
    <div class="times_list times_on">Today</div>
    <div class="times_list">Yesterday</div>
    <div class="times_list">Week</div>
    <div class="times_list">Month</div>
    <div class="times_list">Year</div>
</div>
<div class="times_xk">

    <?php $__currentLoopData = $agent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="times_div" <?php if (! ($key != 'today')): ?> style="display:block;" <?php endif; ?>>
            <div class="times_fl">
                <span class="b1"></span>
                <div class="text">Meus dados do agente  </div>
                <label></label>
            </div>
            <div class="times_sh">
                <table>
                    <thead>
                        <tr>
                            <td>Número</td>
                            <td>Valor do código</td>
                            <td>Recarga total</td>
                            <td>Carga inicial</td>
                        </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td><?php echo e($item['oneGradeInviteNum'] + $item['twoGradeInviteNum']); ?></td>
                        <td><?php echo e($item['oneTbetcoin'] + $item['twoTbetcoin']); ?></td>
                        <td><?php echo e($item['oneRechargeAmount'] + $item['twoRechargeAmount']); ?></td>
                        <td><?php echo e($item['oneFirstRecharge'] + $item['twoFirstRecharge']); ?></td>
                    </tr>
                    </tbody>
                </table>
            </div>
            <div class="times_fl">
                <span class="b2"></span>
                <div class="text">Agente nível 1</div>
                <label></label>
            </div>
            <div class="times_sh">
                    <table>
                    <thead>
                        <tr>
                            <td>Número</td>
                            <td>Valor do código</td>
                            <td>Recarga total</td>
                            <td>Carga inicial</td>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><?php echo e($item['oneGradeInviteNum']); ?></td>
                            <td><?php echo e($item['oneTbetcoin']); ?></td>
                            <td><?php echo e($item['oneRechargeAmount']); ?></td>
                            <td><?php echo e($item['oneFirstRecharge']); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="times_fl">
                <span class="b3"></span>
                <div class="text">Agente nível 2</div>
                <label></label>
            </div>
            <div class="times_sh">
                <table>
                    <thead>
                        <tr>
                        <td>Número</td>
                        <td>Valor do código</td>
                        <td>Recarga total</td>
                        <td>Carga inicial</td>
                        </tr>
                    </thead>
                <tbody>
                    <tr>
                        <td><?php echo e($item['twoGradeInviteNum']); ?></td>
                        <td><?php echo e($item['twoTbetcoin']); ?></td>
                        <td><?php echo e($item['twoRechargeAmount']); ?></td>
                        <td><?php echo e($item['twoFirstRecharge']); ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  

</div>

<script>
    $(function(){
        $('.times_fl').click(function(){
            $(this).next('.times_sh').toggle()
        })
    })
</script><?php /**PATH /Users/lulisong/盒子/bragame/resources/views/brling/share/agent.blade.php ENDPATH**/ ?>